# The Notion SEO Execution System
## Import guide (5 minutes)

Companion to The Google Search Ranking Playbook - by H. Aditya. Five databases that turn the book's roadmap into a working system.

---

## What you get

**1. Roadmap_Tasks.csv - the 12-month execution engine**
26 sequenced tasks across the five phases (Audit, Foundations, Authority, Compounding, Scale & Defend), each with its workstream, exit criterion, and a Status column. The four GATE CHECK rows are the decision gates from Chapter 29 - do not advance phases until they pass.

**2. Content_Tracker.csv - your topical authority planner**
One row per article: cluster, target query, intent, format, status, publish date, internal links, notes. Pre-filled with example rows showing how the system is used (delete them and add your own).

**3. Technical_Audit_Checklist.csv - the quarterly audit**
29 checks across indexation, crawling, rendering, performance, security, schema, and internationalization - each with how to check it and the book chapter to read if it fails.

**4. Keyword_Research_Worksheet.csv - the TARGET/SKIP decision sheet**
One row per keyword: intent, the format the SERP rewards, difficulty, who holds the top 5, and the column that matters most - "Our honest edge". If you cannot fill that column, the Decision is SKIP. This is the method of Chapters 9-10 as a worksheet.

**5. 90_Day_Quickstart.csv - your first 13 weeks**
The 90-day promise, made operational: baseline, audit, first cluster, pillar and supporting articles, first outreach - week by week, with three pass/fail gates. Start here before the 12-month roadmap.

**Bonus (not databases, no import needed):** Beginner_SEO_FAQ.md and Outreach_Templates.md live in the Bonus Resources folder - plain documents, open them anywhere.

---

## How to import into Notion

1. Create a new page in your workspace (for example: "SEO System").
2. Click into the page, then choose **Table > Import > CSV** and select Roadmap_Tasks.csv. Notion creates a full database with all properties.
3. Repeat for Content_Tracker.csv and Technical_Audit_Checklist.csv - keep them as three databases on the same page, separated by headings.
4. Recommended views:
   - Roadmap: group by Phase; sort by Week. Add a "Done" checkbox filter view for weekly standups.
   - Content Tracker: board view grouped by Status (Idea / Drafting / Published / Refreshing) - this becomes your content pipeline.
   - Audit Checklist: filter by Status is empty (open items).
5. Link the two systems: when a Roadmap task produces an article, create the row in Content Tracker and reference it from the task's Notes property.

## How to use the system weekly

- **Monday (10 min):** open Roadmap, run the current week's tasks. Mark done only when the exit criterion is met - not when the task is attempted.
- **Monthly (30 min):** run any new audit section that matches your current phase; update Content Tracker statuses; note gates passed.
- **Quarterly:** full audit checklist pass + refresh cycle (Chapters 11 and 22).

## Works outside Notion too

The CSVs import natively into Excel, Google Sheets, Airtable, and ClickUp. The system is the structure, not the software.
