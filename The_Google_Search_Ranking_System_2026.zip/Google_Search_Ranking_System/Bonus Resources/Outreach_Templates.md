# Outreach Templates - Earned Links Without Spam
### Companion to The Google Search Ranking Playbook - by H. Aditya

Six templates for the outreach approach Chapter 20 teaches: honest,
specific, quality-first. Rules before you send anything:

1. Only contact people whose content you have actually read.
2. You are offering value (a fix, data, a genuine fit) - never asking for
   a favour out of nowhere.
3. One personalized email beats fifty template blasts.
4. No follow-up after the second try. Silence is an answer.

---

## 1. Guest post pitch

**Subject:** [Their site name] + [your niche]: a post idea with original data

Hi [Name],

I have been reading [specific article title - be honest, cite one line you
genuinely found useful]. I noticed your readers ask about [topic gap] and
I have something to offer there.

I have been running [original research / experiment / survey - describe in
one line, include one real finding]. I would like to turn it into a guest
post for [site]: working title "[title]", covering [angle that fills their
gap, not yours]".

I have written for [1-2 real places, or "I publish at [your site]"] - here
are two samples: [links].

Worth a look?

[Your name]

*Why it works: leads with their content, not your request; the data makes
it cite-able for them.*

## 2. Resource-page link request

**Subject:** Small suggestion for your [topic] resources page

Hi [Name],

Your resources page at [URL] is the most complete list on [topic] I have
found - I used it to [be specific].

One small addition you might consider: [your resource URL]. It is
[what it actually is - e.g., a tested comparison of 9 pasta brands with
the full method], which I think fits the standard of the page.

Either way, thanks for maintaining the list.

[Your name]

*Why it works: the giving-framing and the specificity signal a real
visitor, not a blast.*

## 3. Broken-link outreach

**Subject:** A dead link on your [topic] page

Hi [Name],

Quick heads-up: the link to [dead resource] on [page URL] is returning a
404. (Found it because I was looking for that exact resource.)

If it helps as a replacement, I wrote [your resource] - it covers [what it
covers]. If not, a broken link on an otherwise excellent page just bugs me,
so consider this a friendly flag.

[Your name]

*Why it works: you did them a genuine favour first. The link ask is
secondary and optional-feeling because it is.*

## 4. Podcast pitch

**Subject:** Guest idea: what the Google trial transcripts actually say about ranking

Hi [Name],

I have been listening to [episode] - your question about [moment in the
episode] is exactly the one most shows miss.

I write about how search actually works, built from primary sources:
Google's documentation and the U.S. v. Google trial record. I can talk
about [2-3 specific, surprising angles] with the receipts - no vague
"content is king" chat.

Recent writing if useful: [link]. Would this fit a future episode?

[Your name]

## 5. Expert-quote offer (HARO-style)

**Subject:** Data + a quote for your [topic] piece

Hi [Name],

I saw your upcoming piece on [topic] ([URL or where announced]).

I have original data from [your experiment/study]: [one-line headline
finding]. You are welcome to it - full numbers, methodology, and charts,
no strings. If useful, here is a quote you can lift directly:

"[One tight, specific, quotable sentence - a real number or claim.]"

- [Your name], [one-line credential], [your site]

*Why it works: journalists need quotes and data with zero extra work. You
are the easiest source they will deal with today.*

## 6. The follow-up (send ONCE, 7-10 days later)

**Subject:** Re: [original subject]

Hi [Name],

Just floating this back up - in case it was a busy week rather than a no.

[One new line of value: a new finding, an updated number, a thought on
their latest piece.] If the timing is wrong, a simple "not now" works and
I will leave you alone.

[Your name]

*Why it works: it gives an out, adds one new reason, and ends after this -
which is exactly why it converts better than a third attempt.*

---

## Tracking it

Log every send in your Content Tracker (add an "Outreach" note to the
article's row) or a simple sheet: who, what, when, reply, result.
Expect 10-20% honest replies on quality-first outreach; expect silence on
blasts. The full strategy is Chapter 20.
