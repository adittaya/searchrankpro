# Beginner SEO FAQ - The 20 Questions Everyone Asks
### Companion to The Google Search Ranking Playbook - by H. Aditya

Short, honest answers. Every answer follows the book's rule: if it is
documented, we say so; if it is folklore, we say that too.

---

**1. How long does SEO take?**
Expect meaningful movement in 3-6 months on a new site, compounding after
that. The book's roadmap uses pass/fail gates instead of promises - you
advance when your numbers say so, not when a calendar does.

**2. Is SEO dead because of AI Overviews?**
No. Google's own documentation says AI features draw from the same core
ranking systems. What changed: clicks compress on simple informational
queries, and being cited by the AI answer matters. That is why Part IV of
the book exists.

**3. Do I need backlinks to rank?**
For anything competitive, yes - links remain a primary ranking input
(confirmed in the U.S. v. Google trial record). For long-tail questions in
small niches, strong content alone can rank. The strategy: earn links with
something genuinely worth citing (Chapter 20).

**4. How many words should my article be?**
As many as it takes to fully answer the query - no more. Word count is not
a ranking factor. Compare the top results for YOUR query: if they answer
in 800 words and you need 1,500 to do it properly, write 1,500.

**5. Do I need to submit my site to Google?**
Not anymore - but submitting a sitemap in Search Console speeds discovery
and gives you the data you need. It is the first task of the 90-day plan.

**6. What is E-E-A-T?**
Experience, Expertise, Authoritativeness, Trustworthiness - the quality
frame from Google's rater guidelines. It is not a direct ranking "score"
but the systems it describes are real. Practically: show first-hand
experience, name your authors, cite your sources.

**7. Why did my traffic drop after a core update?**
Three honest possibilities: (1) the update rewarded pages that do the job
better, (2) your pages were borderline and recalibrated down, or (3) it is
temporary volatility. Chapter 10's recovery process and Appendix E walk
through diagnosing which one it is.

**8. Can a new site actually rank?**
Yes - on long-tail, low-competition queries in a focused niche. No - on
head terms where established sites with years of trust compete. The book's
niche playbooks (Part VII) are built around exactly this reality.

**9. Is WordPress the best platform for SEO?**
Any mainstream platform works - WordPress, Ghost, Squarespace, Webflow.
What matters: clean URLs, fast pages, crawlable content, easy internal
linking. Pick one you will actually use.

**10. Do SEO plugins actually help?**
They help you implement basics (titles, sitemaps, schema) correctly. They
do not create quality, evidence, or links. A plugin on a bad article is a
well-tagged bad article.

**11. What kills rankings fastest?**
Accidental noindex tags, robots.txt mistakes, and site migrations done
badly. These make you invisible; no content quality can compensate.

**12. Do keywords in the domain still matter?**
Marginally at most, and no professional buys domains for this reason.
Brands are built on names people can remember.

**13. What is search intent, simply?**
What the searcher actually wants when they type the query. Google reads it
from the results people choose. Your page fails when its format does not
match the intent (Chapter 9 is entirely about this).

**14. Can I rank without writing content?**
No. Ranking is Google matching a query to a page; no page, nothing to
rank. The only near-exceptions are tools and data pages that ARE content.

**15. How many keywords should one page target?**
One primary query, plus the close variations of it. A cluster of five
articles targeting five distinct intents beats one article targeting five.

**16. Is internal linking really that important?**
Yes - it is the one link source you fully control, and it tells Google
which pages you consider important. Ten thoughtful internal links can move
a page more than one weak external link.

**17. What is schema markup and do I need it?**
Machine-readable labels on your page (this is an article, by this author,
published then). It does not directly boost ranking, but it enables rich
results, clarifies your entities, and makes content cleanly extractable by
AI features. Ten minutes per page (Chapter 21).

**18. Should I update old content or write new?**
Both, on a schedule - the refresh programme (Chapter 22) is the
highest-ROI editorial process most sites never build. Rule of thumb: if a
page still earns traffic, refresh it; if it earns nothing and cannot be
made excellent, retire it.

**19. Do I need to pay for tools?**
No. Search Console (free) plus your own analytics covers every decision
in the first 90 days. Paid tools save time at scale; they do not create
strategy.

**20. What single thing should I do first?**
The indexation check - fix #1 in the free checklist, Week 3 of the
90-day plan. Everything else is wasted effort on an invisible site.

---

*Every answer here is expanded with sources in The Google Search Ranking
Playbook. If this FAQ helped, the full system is one search away.*
